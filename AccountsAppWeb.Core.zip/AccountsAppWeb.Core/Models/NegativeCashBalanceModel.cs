﻿using System;

namespace AccountsAppWeb.Core.Models
{
    public class NegativeCashBalanceModel
    {
        public decimal Credit { get; set; }
        public DateTime MyTransactinDate { get; set; }
    }
}
