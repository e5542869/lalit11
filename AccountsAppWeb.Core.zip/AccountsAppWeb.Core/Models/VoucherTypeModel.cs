﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountsAppWeb.Core.Models
{
    public class VoucherTypeModel
    {
        public string VoucherTypeName { get; set; }
        public int VoucherTypeId { get; set; }
    }
}
