﻿namespace AccountsAppWeb.Core.Models
{
    public class NatureModel
    {
        public int NatureId { get; set; }
        public string NatureShortTitle { get; set; }
    }
}
