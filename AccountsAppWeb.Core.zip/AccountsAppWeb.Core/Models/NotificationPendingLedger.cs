﻿namespace AccountsAppWeb.Core.Models
{
    public class NotificationPendingLedger
    {
        public string AccountGroupName { get; set; }
        public int LedgerId { get; set; }
        public string LedgerName { get; set; }
        public int Id { get; set; }
    }
}
